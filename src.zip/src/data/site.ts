export const siteMeta = {
	name: 'Lin Yue',
	title: 'Researcher in Open Knowledge Systems and Human-Centered AI',
	description:
		'An academic-style personal homepage for publications, open-source work, writing, and selected updates.',
	email: 'lin.yue@research.example',
	location: 'Shenzhen, China',
	affiliation: 'Independent Research Studio / Visiting Collaborator',
	github: 'https://github.com/example',
	x: 'https://x.com/example',
	scholar: 'https://scholar.google.com/',
	cvHref: '/cv.pdf',
};

export const homeIntro = [
	'I build research software and write about knowledge systems, interactive intelligence, and the craft of transparent tools.',
	'This site collects selected publications, open-source projects, concise essays, and a short CV. The visual language stays restrained on first glance, then responds with quiet depth when touched.',
];

export const cvSummary = {
	statement:
		'My work sits between academic inquiry and practical systems design: research methods that can be explained, software that can be maintained, and interfaces that reward close reading.',
	education: [
		{
			period: '2020-2024',
			title: 'Ph.D. in Information Science',
			meta: 'Institute for Human-Centered Computing',
		},
		{
			period: '2017-2020',
			title: 'M.Eng. in Software Engineering',
			meta: 'Lab for Open Systems and Knowledge Infrastructure',
		},
	],
	experience: [
		{
			period: '2024-Present',
			title: 'Independent Research Engineer',
			meta: 'Open research tooling, scholarly interfaces, and computational archives',
		},
		{
			period: '2021-2024',
			title: 'Research Assistant',
			meta: 'Built reproducible pipelines and public-facing prototypes for academic labs',
		},
	],
	service: [
		'Program committee reviewer for HCI and digital humanities workshops',
		'Maintainer of open-source research tooling and citation utilities',
		'Occasional invited talks on explainable scholarly infrastructure',
	],
};
